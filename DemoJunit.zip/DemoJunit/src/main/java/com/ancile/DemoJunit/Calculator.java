package com.ancile.DemoJunit;

/**
 * Hello world!
 *
 */
public class Calculator 
{
   public int add(int first, int second) {
	   int total = first+second;
	   return total;
   }
}
